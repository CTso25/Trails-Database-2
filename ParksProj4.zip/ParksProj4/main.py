# followed tutorial at https://blog.cloudoki.com/getting-started-with-restful-apis-using-the-flask-microframework-for-python/

from flask import Flask,jsonify, request, Response, render_template, redirect, url_for
import configparser, pymysql, json, requests
from flask_sqlalchemy import SQLAlchemy


# from mysql.connector import MySQLConnection

# workaround because mysqldb is only good for python 2
pymysql.install_as_MySQLdb()

app = Flask(__name__)

# Read config file
config = configparser.ConfigParser()
config.read('dbconnection.conf')

# MySQL configurations
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://' + config.get('DB', 'user') + \
                                     ':' + config.get('DB', 'password') + '@' + \
                                     config.get('DB', 'host') + '/' + config.get('DB', 'db')

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True


mysql = SQLAlchemy()
mysql.init_app(app)


@app.route("/")
def home():
    return render_template("home.html")

@app.route("/about")
def about():
    return render_template("about.html")

#Return trail permit warning for a single trail - simple stored procedure call via API
# http://127.0.0.1:5000/permits?trail=...
@app.route('/permit_result', methods=['GET'])
def getPermitNeeded():
    trail = request.args.get('trail')
    proc_call = "call trailmessage_permit('" + trail + "')"
    result = mysql.engine.execute(proc_call)
    dict_Temp = {}
    for items in result:
        dict_Temp["message"] = items[0]
    value = json.dumps(dict_Temp)
    return Response(value,mimetype='application/json')

# http://127.0.0.1:5000/permits?trail=...
@app.route('/permit', methods=['GET'])
def permitform():
    trail_list = ['Half Dome', 'The Subway Trail', 'Riverside Walk']
    return render_template('permit_temp.html', trail_list = trail_list)






@app.route('/findhike', methods=['GET', 'POST'])
def dropdown():
    if request.method == 'POST':
        return redirect(url_for('bestHike'))
    else:
        park_list = ['Acadia National Park', 'Zion National Park', 'Yosemite National Park']
        level_list = ['Easy', 'Medium', 'Hard']
        features_1= ['Waterfall', 'Gorge', 'Alpine Zone', 'Scrambling', 'River', 'Canyon', 'Climbing',
                        'Water Source', 'Beach', 'Cliffs', 'Scenic Views', 'Fishing', 'Forest', 'Rocky',
                        'Wild Flowers', 'Bird Watching', 'Natural Pools', 'Cave', 'Bridge', 'Lodge/Tea House',
                        'Horseback Riding', 'Lake', 'Cross-Country Skiing', 'Snowshoeing', 'Geyser',
                        'Hot Springs', 'None']
        dog_list = ['Yes', 'No', 'No Preference']
        bath_list = ['Yes', 'No', 'No Preference']
        features_2 = features_1.copy()
        features_3 = features_1.copy()
        features_4 = features_1.copy()
        features_5 = features_1.copy()
        return render_template('findhike.html', park_list = park_list,
                               level_list = level_list,
                               dog_list = dog_list,
                               bath_list = bath_list,
                               features_1=features_1,
                               features_2=features_2,
                               features_3=features_3,
                               features_4=features_4,
                               features_5=features_5,)




#Post method
@app.route('/spotting', methods=['POST'])
def postSpotting():
    animal = request.args.get('animal')
    user = request.args.get('user')
    trail = request.args.get('trail')
    quantity = request.args.get('quantity')
    lat = request.args.get('lat')
    lon = request.args.get('lon')
    desc = request.args.get('desc')
    proc_call = "call add_spotting('" + animal + "','"+ user + "','" + trail + \
                "','" + quantity + "','" + lat + "','" + lon + "','" + desc + "')"
    mysql.session.execute(proc_call)
    mysql.session.commit()

    return ('The '+ animal + ' spotting was successfully reported!\
    Please remember to excercise caution when dealing with wildlife - NPS is not liable for your actions.')



#Find a Hike with None Options
@app.route('/besthike', methods=['GET'])
def findBestHike():
    park = request.args.get('park')
    level = request.args.get('level') #('Easy', 'Moderate', 'Hard')
    min = request.args.get('min')
    max = request.args.get('max')
    bath= request.args.get('bath')
    dog= request.args.get('dog')
    feat1= request.args.get('feat1')
    feat2= request.args.get('feat2')
    feat3= request.args.get('feat3')
    feat4= request.args.get('feat4')
    feat5= request.args.get('feat5')
    proc_call = "call find_best_hike('" + park + "','" + level + "','" + min + "','" + max + "','" + bath + "','" \
                + dog + "','" + feat1 + "','" + feat2 + "','" + feat3 + "','" + feat4 + "','" + feat5 + "')"
    print(proc_call)
    result = mysql.engine.execute(proc_call)
    data_all = []
    for item in result:
        data_all.append([item['trail name'], str(item['distance in miles']), item['description'],
                         str(item['average user rating']), item['features'], item['messages']])
    return jsonify(trails=data_all),{'Content-Type':'application/json'}


if __name__ == "__main__":
    app.run(debug = True)